package com.example.ekaterinburg_duma_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
